<title>Color Bets</title>
<link rel="shortcut icon" type="image/png" href="logo9.jpg"/>