<?php

interface com_wiris_plugin_api_AccessProvider {
	function requireAccess();
}
